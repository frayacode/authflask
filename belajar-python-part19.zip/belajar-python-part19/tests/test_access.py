import pytest
from app import create_app
from models import db, User, Post, ROLE_ADMIN, ROLE_USER


@pytest.fixture
def app():
    app = create_app({
        "TESTING": True,
        "SQLALCHEMY_DATABASE_URI": "sqlite:///:memory:",
        "SECRET_KEY": "test",
    })
    with app.app_context():
        db.drop_all()
        db.create_all()
        for name, role in [("admin", ROLE_ADMIN), ("budi", ROLE_USER), ("siti", ROLE_USER)]:
            u = User(username=name, role=role)
            u.set_password("rahasia123")
            db.session.add(u)
        db.session.commit()
        budi = User.query.filter_by(username="budi").first()
        db.session.add(Post(title="Milik Budi", body="isi", user_id=budi.id))
        db.session.commit()
    yield app


@pytest.fixture
def client(app):
    return app.test_client()


def login(client, username, next_url=None):
    url = "/login" + (f"?next={next_url}" if next_url else "")
    return client.post(url, data={"username": username, "password": "rahasia123"})


def test_admin_page_redirects_when_anonymous(client):
    r = client.get("/admin/users")
    assert r.status_code == 302
    assert "/login" in r.headers["Location"]


def test_regular_user_gets_403_on_admin_page(client):
    login(client, "budi")
    assert client.get("/admin/users").status_code == 403


def test_admin_can_open_admin_page(client):
    login(client, "admin")
    assert client.get("/admin/users").status_code == 200


def test_user_cannot_edit_others_post(client):
    login(client, "siti")
    assert client.get("/posts/1/edit").status_code == 403


def test_owner_and_admin_can_edit_post(client):
    login(client, "budi")
    assert client.get("/posts/1/edit").status_code == 200
    client.get("/logout")
    login(client, "admin")
    assert client.get("/posts/1/edit").status_code == 200


def test_register_cannot_choose_role(client, app):
    client.post("/register", data={"username": "nakal", "password": "abcdef", "role": "admin"})
    with app.app_context():
        assert User.query.filter_by(username="nakal").first().role == ROLE_USER


def test_open_redirect_is_blocked(client):
    r = login(client, "budi", next_url="https://situs-jahat.example")
    assert r.status_code == 302
    assert "situs-jahat" not in r.headers["Location"]


def test_admin_cannot_demote_self(client, app):
    login(client, "admin")
    with app.app_context():
        admin_id = User.query.filter_by(username="admin").first().id
    client.post(f"/admin/users/{admin_id}/role", data={"role": "user"})
    with app.app_context():
        assert db.session.get(User, admin_id).role == ROLE_ADMIN


def test_invalid_role_rejected(client, app):
    login(client, "admin")
    with app.app_context():
        uid = User.query.filter_by(username="budi").first().id
    assert client.post(f"/admin/users/{uid}/role", data={"role": "superuser"}).status_code == 400
